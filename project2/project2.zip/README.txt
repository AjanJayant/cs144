Ajan Jayant, 904039631

1. Here's a list of my relations

Item(*ItemID, UserID, Name, BuyPrice, FirstBid, Started, Ends, Description)
User(*UserID, Rating, Location, Country)
ItemCategory(ItemID, Category)
Bid(*BidID, UserID, ItemID, Time, Amount)

where * denotes the keys

2. All of non-trivial funtional dependenices specifiy keys in my relations.

3. All my relations are in BCNF
